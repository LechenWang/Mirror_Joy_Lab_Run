import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  base: '/Mirror_Joy_Lab_Run/',
  plugins: [react()],
})
