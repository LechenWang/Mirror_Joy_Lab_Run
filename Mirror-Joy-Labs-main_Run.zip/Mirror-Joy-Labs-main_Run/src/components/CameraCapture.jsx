import React, { useRef, useEffect, forwardRef, useImperativeHandle } from 'react';

const CameraCapture = forwardRef(({ onCapture }, ref) => {
  const videoRef = useRef();
  const canvasRef = useRef();

  useEffect(() => {
    navigator.mediaDevices.getUserMedia({ video: true }).then((stream) => {
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    });

    return () => {
      if (videoRef.current?.srcObject) {
        videoRef.current.srcObject.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const takePhoto = () => {
    const ctx = canvasRef.current.getContext('2d');
    ctx.drawImage(videoRef.current, 0, 0, 640, 480);
    const image = canvasRef.current.toDataURL('image/jpeg', 0.9);
    if (onCapture) {
      onCapture(image);
    }
  };

  useImperativeHandle(ref, () => ({
    takePhoto
  }));

  return (
    <div style={{ textAlign: 'center' }}>
      <video ref={videoRef} width="640" height="480" style={{ borderRadius: '8px' }} />
      <canvas ref={canvasRef} width="640" height="480" style={{ display: 'none' }} />
    </div>
  );
});

export default CameraCapture;
