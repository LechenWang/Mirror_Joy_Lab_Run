// src/pages/SkinResult.jsx
import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import '../style/SkinResult.css';

function skinTypeToText(type) {
  switch (type) {
    case 0: return '油性皮肤';
    case 1: return '干性皮肤';
    case 2: return '中性皮肤';
    case 3: return '混合型皮肤';
    default: return '未知';
  }
}

function SkinResult() {
  const { state } = useLocation();
  const navigate = useNavigate();

  const image = state?.imageData;
  const report = state?.report;

  if (!image || !report) {
    return <p className="error-text">无数据，请返回重新拍照。</p>;
  }

  return (
    <div className="result-container">
      <h2 className="title">我的肤质报告</h2>
      <p className="score-text">
        你的皮肤已经超过 <span className="highlight">{report.rank || '90%'}</span> 的用户
      </p>

      <div className="content-box">
        <div className="photo-preview">
          <img src={image} alt="用户拍照" />
        </div>

        <div className="skin-report">
          <div className="report-card large">
            <p>肤质：</p>
            <h3>{skinTypeToText(report.skin_type?.skin_type)}</h3>
          </div>
          <div className="report-grid">
            <div className="report-card">黑头：<strong>{report.blackhead?.value ? '有' : '无'}</strong></div>
            <div className="report-card">痘痘：<strong>{report.acne?.value ? '有' : '无'}</strong></div>
            <div className="report-card">闭口：<strong>{report.closed_comedo?.value ? '有' : '无'}</strong></div>
          </div>
        </div>
      </div>

      <div className="action-buttons">
        <button className="btn-gradient" onClick={() => navigate('/product-recommend', { state: { report } })}>查看推荐</button>
        <button className="btn-gradient" onClick={() => navigate('/share')}>分享</button>
      </div>

      <p className="retry-text" onClick={() => navigate('/skin-ai')}>重新测试</p>
    </div>
  );
}

export default SkinResult;
