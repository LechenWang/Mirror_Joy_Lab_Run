import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import products from '../data/products.json';
import '../style/ProductRecommend.css';

function ProductRecommend() {
  const { state } = useLocation();
  const report = state?.report;
  const navigate = useNavigate();

  const [scoredProducts, setScoredProducts] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const itemsPerPage = 4;

  useEffect(() => {
    if (!report) {
      navigate('/');
      return;
    }

    const skinType = report.skin_type?.skin_type;
    const hasAcne = report.acne?.value === 1;
    const hasBlackhead = report.blackhead?.value === 1;
    const hasDarkCircle = report.dark_circle?.value === '1';

    // Enhanced scoring system
    const scored = products.map(p => {
      let score = 0;
      
      // Base score for skin type compatibility (0-3 points)
      if (p.suitable_skin.includes(skinType)) {
        score += 3;
      }

      // Concern-specific scoring (0-2 points per concern)
      const concerns = [];
      if (hasAcne) concerns.push('acne');
      if (hasBlackhead) concerns.push('blackhead');
      if (hasDarkCircle) concerns.push('dark_circle');

      concerns.forEach(concern => {
        if (p.targets.includes(concern)) {
          score += 2;
        }
      });

      // Product type priority based on skin type
      const typePriority = {
        0: ['cleanser', 'toner', 'serum'], // Oily skin
        1: ['moisturizer', 'serum', 'mask'], // Dry skin
        2: ['toner', 'serum', 'moisturizer'], // Normal skin
        3: ['toner', 'serum', 'moisturizer'] // Combination skin
      };

      if (typePriority[skinType]?.includes(p.type)) {
        score += 1;
      }

      // Price range consideration
      const price = parseInt(p.price.replace('￥', ''));
      if (price <= 200) score += 0.5; // Budget-friendly bonus
      if (price >= 500) score += 0.5; // Premium product bonus

      return { ...p, score };
    });

    // Sort by score and filter out products with zero score
    scored.sort((a, b) => b.score - a.score);
    const recommended = scored.filter(p => p.score > 0);

    // Group products by type for better organization
    const groupedProducts = recommended.reduce((acc, product) => {
      if (!acc[product.type]) {
        acc[product.type] = [];
      }
      acc[product.type].push(product);
      return acc;
    }, {});

    // Flatten the grouped products while maintaining type grouping
    const organizedProducts = Object.values(groupedProducts).flat();
    setScoredProducts(organizedProducts);
    setCurrentIndex(0);
  }, [report, navigate]);

  const currentItems = scoredProducts.slice(currentIndex, currentIndex + itemsPerPage);

  const handlePrev = () => {
    setCurrentIndex((prev) => Math.max(prev - itemsPerPage, 0));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => Math.min(prev + itemsPerPage, scoredProducts.length - itemsPerPage));
  };

  const getScoreStars = (score) => {
    const fullStars = Math.floor(score);
    const hasHalfStar = score % 1 >= 0.5;
    return '⭐'.repeat(fullStars) + (hasHalfStar ? '⭐' : '');
  };

  return (
    <div className="product-recommend-page">
      <h2 className="product-recommend-title">为你推荐的护肤产品</h2>
      {scoredProducts.length === 0 && <p className="product-recommend-empty">未找到符合条件的产品</p>}

      <div className="product-recommend-slider">
        {currentIndex > 0 && (
          <button onClick={handlePrev} className="slider-arrow slider-arrow-left">←</button>
        )}

        <div className="product-list">
          {currentItems.map((item) => (
            <div key={item.id} className="product-card">
              <img src={item.image} alt={item.name} className="product-image" />
              <h4 className="product-name">{item.name}</h4>
              <p className="product-price">{item.price}</p>
              <p className="product-type">类型：{item.type}</p>
              <p className="product-score">推荐指数：{getScoreStars(item.score)}</p>
              <p className="product-targets">针对：{item.targets.join(', ')}</p>
            </div>
          ))}
        </div>

        {currentIndex + itemsPerPage < scoredProducts.length && (
          <button onClick={handleNext} className="slider-arrow slider-arrow-right">→</button>
        )}
      </div>

      <button onClick={() => navigate('/skin-ai')} className="back-button">
        返回重新测肤
      </button>
    </div>
  );
}

export default ProductRecommend;
