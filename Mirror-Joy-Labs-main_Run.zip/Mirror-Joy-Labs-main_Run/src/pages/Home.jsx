// src/pages/Home.jsx
import { Link } from 'react-router-dom';
import '../style/Home.css';
import logo from '../assets/logo.png'; // 假设logo图标为svg格式

function Home() {
  return (
    <div className="home-container">
      <div className="logo-section">
        <img src={logo} alt="Mirror Joy Logo" className="logo" />
        {/* <p className="brand-text">Mirror Joy Labs</p> */}
      </div>

      <div className="button-section">
        <Link to="/skin-ai" className="card-button blue">
          <div className="text-group">
            <h2>智能测肤 <span className="tag">（测试版）</span></h2>
            <p>十秒测出肤质，给你专业的产品推荐</p>
          </div>
          <span className="arrow">↗</span>
        </Link>

        <div className="card-button pink disabled">
          <div className="text-group">
            <h2>线上试妆 <span className="tag">（功能未开发）</span></h2>
            <p>十秒测出你的肤质，给你专业的产品推荐</p>
          </div>
          <span className="arrow">↗</span>
        </div>
      </div>

      <p className="footer">present by - Mirror Joy Labs</p>
    </div>
  );
}

export default Home;
