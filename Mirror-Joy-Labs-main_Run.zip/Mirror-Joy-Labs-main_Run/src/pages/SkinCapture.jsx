import React, { useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import CameraCapture from '../components/CameraCapture';

function SkinCapture() {
  const navigate = useNavigate();
  const cameraRef = useRef();

  const handleCapture = (imageData) => {
    console.log('📸 图片已捕获，跳转中...');
    navigate('/skin-loading', { state: { imageData } });
  };

  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h2>请拍照</h2>

      <CameraCapture ref={cameraRef} onCapture={handleCapture} />

      <button
        onClick={() => cameraRef.current?.takePhoto()}
        style={{
          marginTop: '16px',
          padding: '10px 20px',
          fontSize: '16px',
          backgroundColor: '#6c63ff',
          color: 'white',
          border: 'none',
          borderRadius: '10px',
          cursor: 'pointer'
        }}
      >
        📸 拍照
      </button>
    </div>
  );
}

export default SkinCapture;
