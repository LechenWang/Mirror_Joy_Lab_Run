// src/pages/TryOnAI.jsx
function TryOnAI() {
    return (
      <div>
        <h2>AI 试妆</h2>
        <p>这里是虚拟试妆的功能区。</p>
      </div>
    );
  }
  
  export default TryOnAI;
  