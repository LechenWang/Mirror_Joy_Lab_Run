import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { analyzeSkin } from '../utils/faceppSkinApi.js';

function SkinLoading() {
  const { state } = useLocation();
  const navigate = useNavigate();
  const imageData = state?.imageData;

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!imageData) {
      setError('没有接收到图像数据');
      return;
    }

    const analyze = async () => {
      try {
        const result = await analyzeSkin(imageData);
        console.log("🧪 分析结果：", result);
        // 分析完成后跳转到结果页，带上报告
        navigate('/skin-result', {
          state: {
            imageData,
            report: result.result
          }
        });
      } catch (err) {
        console.error("❌ 分析失败:", err);
        setError('分析失败，请稍后重试');
        setLoading(false);
      }
    };

    analyze();
  }, [imageData, navigate]);

  if (error) {
    return (
      <div style={{ textAlign: 'center', padding: '20px', color: 'red' }}>
        <h2>出错了</h2>
        <p>{error}</p>
        <button onClick={() => navigate(-1)}>返回重试</button>
      </div>
    );
  }

  return (
    <div style={{ textAlign: 'center', padding: '20px' }}>
      <h2>正在分析，请稍候...</h2>
      <p>图像上传成功，正在分析肤质</p>
      <img src={imageData} alt="用户照片" style={{ width: '320px', borderRadius: '8px', marginTop: '10px' }} />
      {loading && <p style={{ color: '#888' }}>连接 Face++ 接口中...</p>}
    </div>
  );
}

export default SkinLoading;
